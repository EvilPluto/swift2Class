//
//  initFood.swift
//  Swift2Class
//
//  Created by mac on 16/10/28.
//  Copyright © 2016年 team. All rights reserved.
//

import Foundation

// 由于数据持久化，此类已抛弃
